import processing.core.*; 
import processing.xml.*; 

import processing.opengl.*; 
import controlP5.*; 

import java.applet.*; 
import java.awt.*; 
import java.awt.image.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Papermill_web1 extends PApplet {


XMLElement xml;

ControlP5 toggle;



PFont font1;
PFont font2;
PFont font3;


PreferenceV1 PV1;
Visualiser5axis vs1;

PImage logo;


boolean myMouseClick = false;






public void setup(){
  size(1024, 768, OPENGL);
  xml = new XMLElement(this, "papermilldata.xml");
  font1 = loadFont("MyriadPro-Regular-16.vlw");
  font2 = loadFont("ArialNarrow-14.vlw");
  font3 = loadFont("ArialNarrow-11.vlw");
  frameRate(2);
  background(28);
  logo = loadImage("logo3.png");
  PV1 = new PreferenceV1();



  vs1 = new Visualiser5axis(xml,1400);
  vs1.readData();




  toggle = new ControlP5(this);
  //PARAMETERS
  toggle.addToggle("",true,824,168,10,10); //bonding
  toggle.addToggle("",true,824,192,10,10); //bulk
  toggle.addToggle("",false,824,216,10,10); //burst index
  toggle.addToggle("",true,824,240,10,10); //Fiber length
  toggle.addToggle("",true,824,264,10,10); //Freeness
  toggle.addToggle("",false,824,288,10,10); //SEC
  toggle.addToggle("",true,824,312,10,10); //Tear index
  toggle.addToggle("",false,824,336,10,10); //Tensile index
  //VIEW OPTIONS
  toggle.addToggle("",false,824,402,10,10); //Value
  toggle.addToggle("",false,824,426,10,10); //Limits
  toggle.addToggle("",false,824,450,10,10); //Margins
  toggle.addToggle("",true,824,474,10,10); //Energy Efficiency
  toggle.setColorForeground(color(80));
  toggle.setColorActive(color(255));



}




public void draw(){
  background(25);

  image(logo,895,645);
  vs1.display();

  // Main menu
  pushMatrix();
  translate(36,48);
  noStroke();
  fill(255);
  textFont(font1);
  textAlign(LEFT);
  text("Realtime",0,0);
  fill(120);
  text("History",90,0);
  fill(255);
  text("Refiner #1",0,24);
  popMatrix();

  //Dropdown triangel
  pushMatrix();
  translate(114,62);
  noStroke();
  fill(225);
  triangle(0, 0, 12.125f, 0, 12.125f/2, 10.5f);
  popMatrix();  


  //Date and Time
  pushMatrix();
  translate(986,48);
  noStroke();
  fill(255);
  textFont(font1);
  textAlign(RIGHT);

  int ss = second();  // Values from 0 - 59
  int mm = minute();  // Values from 0 - 59
  int hh = hour();    // Values from 0 - 23
  String clock = hh + " : " + mm + " : "+ ss;
  //text("Thursday " ,-80,0);
  text( clock ,0,0);

  int da = day();    // Values from 1 - 31
  int mo = month();  // Values from 1 - 12
  int ye = year();   // 2003, 2004, 2005, etc.
  String date = ye + " - " + mo + " - "+ da;
  text(date,0,24);  
  popMatrix();

  PV1.display();




}





public void mouseClicked(){

  myMouseClick = true;

}


class PreferenceV1{




  PreferenceV1(){

  }




  public void display(){

    // Graphic


    pushMatrix();
    translate(804,86);
    noStroke();
    fill(0);
    rect(0,0,220,420);
    strokeWeight(1.5f);
    stroke(255);
    line(17,68,182,68);
    line(17,304,182,304);    

    //Dropdown triangel
    pushMatrix();
    translate(172,19);
    noStroke();
    fill(225,255,77);
    triangle(0, 10.5f, 12.125f, 10.5f, 12.125f/2, 0);
    popMatrix();  


    popMatrix(); 


    // Text 
    pushMatrix();
    translate(804,86);
    noStroke();
    fill(255);
    textFont(font1);
    int ind1 = 42;
    textAlign(LEFT);
    fill(225,255,77);
    text("DISPLAY PREFERENCE",16,30);
    fill(255);
    text("PARAMETERS",16,62);
    text("Bonding",ind1,92);
    text("Bulk",ind1,116);
    text("Burst index",ind1,140);
    text("Fiber length",ind1,164);
    text("Freeness",ind1,188);
    text("SEC",ind1,212);
    text("Tear index",ind1,236);
    text("Tensite index",ind1,260);

    text("VIEW OPTIONS",16,298);
    text("Value",ind1,326);
    text("Limits",ind1,350);
    text("Margins",ind1,374);
    text("Energy Efficiency",ind1,398);

    popMatrix();
  }












}





class Visualiser5axis
{
  XMLElement xml;
  




  
  
  int cols = 9;
  int rows = 180;
  int step = 30;
  float [][] A = new float[rows][cols];
  float [][] B = new float[rows*step][cols];
  float [][] K = new float[rows][cols];


  int i=800;
  int wait=1;
  int baseColour = 25;
  float alarm = 0;


  Visualiser5axis(XMLElement exml, int start) {
    xml = exml;
    i = start;

  } 






  public void readData()
  {
    // Assign raw data to matrix A[][]
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        XMLElement onePoint = xml.getChild(i);
        A[i][j] = PApplet.parseFloat(onePoint.getChild(j).getContent());
      }
    }

    // calculate gap in each step and assign to matrix K[][]
    for (int i = 1; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        K[i-1][j] = (A[i][j] - A[i-1][j])/step;
      }
    }

    // Calculate plotting value ,row of matrix multiply by step
    /* example
     B[][] = [    A0           B0           C0           D0    ]
     A0 += KA0    B0 += KB0    C0 += KC0    D0 += KD0
     */
    // Assign Value for first row in plotting matrix B[][]
    for (int n = 0; n < cols; n++) {
      B[0][n] = A[0][n]; 
    }

    // Assign Value for the rest rows in plotting matrix B[][]
    int k=1; 
    int i=0;
    for (int m = 1; m < rows*step; m++) {    

      for (int n = 0; n < cols; n++){
        B[m][n] = B[m-1][n] + K[i][n];
      }

      // change K[][] value when complete steps
      k++;
      if (k == step+1){
        k=1;
        i++;
      }
    }
    

  }







  public void display(){
    //start drawing
    smooth();
    //background(baseColour);
    float w=width/2-100, h=height/2;
    int l=250;
    float deg=2*PI/5;
    float deg2=3*PI/10;
    float op = 5;
    int repeat = rows*step;
    int history = 85;
    float eff = interpolate(B[i][8],1.65f,1.83f);
    //println(eff + "  "+B[i][8]);

    //declare war
    pushMatrix();
    translate(w,h);


    wait--;
    if (wait == 0){
      wait = 1;

      if (i < repeat-history){
        i++;
      }

      if (i == repeat-history){
        i=0;
      }
    }


    //set environment

    drawGradientDisc(0, 0,310,310, color(eff/1.6f,50,200-eff/1.8f,255),color(eff/1.6f,30,200-eff/1.8f,0));

    

    stroke(255, 200);
    strokeWeight(1);

    if (alarm > 200){
      fill(random(255),0,0,random(140,255));
      ellipseMode(CENTER);
      ellipse(0,0,500,500);

    }
    else{
      fill(baseColour);
      drawGradientDisc(0, 0,250,250, color(60,255),color(23,255));
 
    }

    //ellipseMode(CENTER);
    //ellipse(0,0,500,500);




    //noFill();
    stroke(255, 50);
    strokeWeight(.1f);
    fill(baseColour);
    noStroke();
    ellipse(0,0,400,400);
    drawGradientDisc(0, 0,200,200, color(60,255),color(25,255));

    noFill();
    stroke(255, 50); 
    strokeWeight(.1f); 
    int li=326;
    line(0,-li,0,0);
    textFont(font2);
    fill(120);
    textAlign(LEFT);
    text("Freeness",2,-315);
    text("Tear index",330*sin(deg), -324*cos(deg));
    text("Bulk",330*cos(deg2), 337*sin(deg2));
    textAlign(RIGHT);
    text("Fiber length",-330*sin(deg), -324*cos(deg));
    text("Bonding",-330*cos(deg2), 337*sin(deg2));
    line(0, 0,li*sin(deg), -li*cos(deg));
    line(0, 0,-li*sin(deg), -li*cos(deg));
    line(0, 0,li*cos(deg2), li*sin(deg2));
    line(0, 0,-li*cos(deg2), li*sin(deg2));
    //set environment ending   



noFill();

    for (int j=i ; j < i+history; j++){


      //get data from array, interpolate abd absolut with return funtion down there
      float Pa = interpolate(B[j][0], 1.60f, 1.75f);
      float Pb = interpolate(B[j][1], 25.46f, 27.20f);
      float Pc = interpolate(B[j][2], 15.03f, 16.30f);
      float Pd = interpolate(B[j][3], 7.40f, 8.70f);
      float Pe = interpolate(B[j][4], 556, 585);
      //float Pf = interpolate(A[j][5], 4.53, 5.5);
      //float Pg = interpolate(A[j][6], 70.88, 72.5);
      //float Ph = interpolate(A[j][7], 14.33, 16.10);

      alarm = Pe;
      //println(alarm);
      //start plotting

      //println(int(Pa) + "   "  +int(Pb) + "   "  +int(Pc) + "   "  +int(Pd) + "   "  +int(Pe)  +"   "+A[j][8]);



      //plot history lines


      if (j != i+history-1){

        strokeWeight(0.45f);
        stroke(150, op);
        beginShape();
        vertex(0 , -Pa);
        vertex(Pb*sin(deg), -Pb*cos(deg));
        vertex(Pc*cos(deg2), Pc*sin(deg2));
        vertex(-Pd*cos(deg2), Pd*sin(deg2));
        vertex(-Pe*sin(deg), -Pe*cos(deg));
        endShape(CLOSE);
      }

      //plot the last brightest line
      else{
        // colour the shape when the values go out of limit

        float alp = 0;

        if ( Pa > 150 || Pb > 150 || Pc > 150 || Pd > 150 || Pe > 150){
          float[] offMargin = {
            Pa, Pb, Pc, Pd, Pe                            };
          alp = max(offMargin);
          fill(255,242,0,alp%140*4);  
          stroke(255,242,0);
          beginShape();
          vertex(0 , -Pa);
          vertex(Pb*sin(deg), -Pb*cos(deg));
          vertex(Pc*cos(deg2), Pc*sin(deg2));
          vertex(-Pd*cos(deg2), Pd*sin(deg2));
          vertex(-Pe*sin(deg), -Pe*cos(deg));
          endShape(CLOSE);
          for (int g = 1; g < 255; g++)
          {
            stroke(255,242,0,alp%140*7/g);  
            //stroke(255,255,0, 255/g);
            noFill();
            strokeWeight(1.3f);
            //ellipse(height/2, width/2, r+glow, r+glow);
            beginShape();
            vertex(0 , -Pa-g);
            vertex((Pb+g)*sin(deg), (-Pb-g)*cos(deg));
            vertex((Pc+g)*cos(deg2), (Pc+g)*sin(deg2));
            vertex((-Pd-g)*cos(deg2), (Pd+g)*sin(deg2));
            vertex((-Pe-g)*sin(deg), (-Pe-g)*cos(deg));
            endShape(CLOSE);
            fill(255);
          }

          //stroke(255, 255);
          //strokeWeight(0.8);
        }

        else{ 
          stroke(255, 255);
          strokeWeight(1.4f);


          beginShape();
          vertex(0 , -Pa);
          vertex(Pb*sin(deg), -Pb*cos(deg));
          vertex(Pc*cos(deg2), Pc*sin(deg2));
          vertex(-Pd*cos(deg2), Pd*sin(deg2));
          vertex(-Pe*sin(deg), -Pe*cos(deg));
          endShape(CLOSE);
          fill(255);
        }
      }

      op += 0.8f;
      //end of each line
    }
    //END OF EACH SET!

    //reset line opaque
    op = 0;
    popMatrix();

    //End of the plot
  }



  //interpolate data
  public float interpolate(float Px, float target, float maximum){
    float k = 250/(maximum-target);
    Px = abs((Px-target)*k);
    return Px;
  }







  //gradient

  public void drawGradientDisc(float x,float y, float radiusX, float radiusY, int innerCol, int outerCol) {
    noStroke();
    beginShape(TRIANGLE_STRIP);
    for(float theta=0; theta<TWO_PI; theta+=TWO_PI/36) {
      fill(innerCol);
      vertex(x,y);
      fill(outerCol);
      vertex(x+radiusX*cos(theta),y+radiusY*sin(theta));
    }
    endShape();
  } 















}






  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#666666", "--stop-color=#cccccc", "Papermill_web1" });
  }
}
