import processing.core.*; 
import processing.xml.*; 

import processing.opengl.*; 
import controlP5.*; 

import java.applet.*; 
import java.awt.*; 
import java.awt.image.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Papermill_Semifinal2 extends PApplet {


XMLElement xml;

ControlP5 toggle;
PImage historyGraph;
PImage controller;
PImage calendar;
PImage logo;
HScrollbar hs1;


//CheckBox checkbox;
//CheckBox checkbox2;

PFont font1;
PFont font2;
PFont font3;


PreferenceV2 PV2;
VisualiserInteractive VI;
//Visualiser5axis vs1;









public void setup(){
  size(1024, 768, OPENGL);
  xml = new XMLElement(this, "papermilldata.xml");
  int numSites = xml.getChildCount();  
  font1 = loadFont("MyriadPro-Regular-16.vlw");
  font2 = loadFont("ArialNarrow-14.vlw");
  font3 = loadFont("ArialNarrow-11.vlw");
  //frameRate(25);
  background(28);

  PV2 = new PreferenceV2();
  VI = new VisualiserInteractive(xml, numSites);
  VI.readData();
  hs1 = new HScrollbar(36, 305, 744, 360, 4);  

  historyGraph = loadImage("history_graph.png");
  controller = loadImage("controller.png");
  calendar = loadImage("calendar.png");
  //vs1 = new Visualiser5axis(xml);
  //vs1.readData();

  logo = loadImage("logo3.png");



  toggle = new ControlP5(this);
  //PARAMETERS
  toggle.addToggle("",true,824,168,10,10); //bonding
  toggle.addToggle("",true,824,192,10,10); //bulk
  toggle.addToggle("",false,824,216,10,10); //burst index
  toggle.addToggle("",true,824,240,10,10); //Fiber length
  toggle.addToggle("",true,824,264,10,10); //Freeness
  toggle.addToggle("",false,824,288,10,10); //SEC
  toggle.addToggle("",true,824,312,10,10); //Tear index
  toggle.addToggle("",false,824,336,10,10); //Tensile index

  //HISTORY
  toggle.addToggle("",true,852,168,10,10); //bonding
  toggle.addToggle("",false,852,192,10,10); //bulk
  toggle.addToggle("",false,852,216,10,10); //burst index
  toggle.addToggle("",true,852,240,10,10); //Fiber length
  toggle.addToggle("",false,852,264,10,10); //Freeness
  toggle.addToggle("",false,852,288,10,10); //SEC
  toggle.addToggle("",true,852,312,10,10); //Tear index
  toggle.addToggle("",false,852,336,10,10); //Tensile index

  //VIEW OPTIONS
  toggle.setColorForeground(color(120));
  toggle.setColorActive(color(255));
  toggle.addToggle("",false,824,402,10,10); //Value
  toggle.addToggle("",true,824,426,10,10); //Limits
  toggle.addToggle("",true,824,450,10,10); //Target value
  toggle.addToggle("",true,824,474,10,10); //Energy Efficiency




}




public void draw(){
  background(28);

  VI.update(hs1.getPos());
  VI.display();



  // Main menu
  pushMatrix();
  translate(36,48);
  noStroke();
  fill(120);
  textFont(font1);
  textAlign(LEFT);
  text("Realtime",0,0);
  fill(255);
  text("History",90,0);
  fill(255);
  text("Refiner #1",0,24);
  popMatrix();

  //Dropdown triangel
  pushMatrix();
  translate(114,62);
  noStroke();
  fill(225);
  triangle(0, 0, 12.125f, 0, 12.125f/2, 10.5f);
  popMatrix();  


  //Date and Time
  pushMatrix();
  translate(986,48);
  noStroke();
  fill(255);
  textFont(font1);
  textAlign(RIGHT);

  int ss = second();  // Values from 0 - 59
  int mm = minute();  // Values from 0 - 59
  int hh = hour();    // Values from 0 - 23
  String clock = hh + " : " + mm + " : "+ ss;
  text("Thursday " ,-80,0);
  text( clock ,0,0);

  int da = day();    // Values from 1 - 31
  int mo = month();  // Values from 1 - 12
  int ye = year();   // 2003, 2004, 2005, etc.
  String date = ye + " - " + mo + " - "+ da;
  text(date,0,24);  
  popMatrix();





  //HISTORY GRAPH
  pushMatrix();
  translate(36,86);
  noStroke();
  fill(0);
  rect(0,0,744,420);
  fill(60);
  rect(0,40,744,360);
  noStroke();
  image(historyGraph,0,0);
  image(controller,480,436);
  image(calendar,16,460);


  //rect(0,40,744,360);


  popMatrix();









  PV2.display();
  hs1.update();
  hs1.display();
  image(logo,895,645);

}









class Checkbox{
  
  boolean myMouseClick=true;
  int x2pos, y2pos;    // width and height of box
  int xpos, ypos;         // x and y position of box
  boolean over;           // is the mouse over the box?
  boolean locked;       // click and lock and load!!
  int boxWidth, boxHeight;
  int rollover = color(0, 189, 242);
  int off = color(120);
  int on = color(255);
  boolean boxChecked = true;

  Checkbox(int xp, int yp, int bw, int bh){
    xpos = xp;
    ypos = yp;
    x2pos = xpos + bw;
    y2pos = ypos + bh;
    boxWidth = bw;
    boxHeight = bh;
  }





  public void update() {
    if(over()) {
      over = true;
    } 
    else {
      over = false;
    }
    if(mousePressed && over) {
      locked = true;
    }
    if(!mousePressed) {
      locked = false;
    }

  }



  public boolean over() {
    if(mouseX > xpos && mouseX < x2pos &&
      mouseY > ypos && mouseY < y2pos) {
      return true;
    } 
    else {
      return false;
    }
  }


  public void Checking(){      // boxChecked or not?
    if(over && myMouseClick) 
    {
     // println(myMouseClick);
      if (boxChecked == true){
        boxChecked = false;
      }
      else{
        boxChecked = true;
      }
          println(boxChecked);
    } 

    myMouseClick = false;
  }



  public void display() {
    fill(on);
    noStroke();
    rect(xpos, ypos, boxWidth, boxHeight);
    if(over || locked) {
      fill(rollover);
    } 
    else {
      if (boxChecked){
        fill(on);
      }
      else {
        fill(off);
      }
    }
    rect(xpos, ypos, boxWidth, boxHeight);
    Checking();
  }





}



class HScrollbar
{
  int swidth, sheight;    // width and height of bar
  int xpos, ypos;         // x and y position of bar
  float spos, newspos;    // x position of slider
  int sposMin, sposMax;   // max and min values of slider
  int loose;              // how loose/heavy
  boolean over;           // is the mouse over the slider?
  boolean locked;
  float ratio;

  HScrollbar (int xp, int yp, int sw, int sh, int l) {
    swidth = sw;
    sheight = sh;
    int widthtoheight = sw - sh;
    ratio = (float)sw / (float)widthtoheight;
    xpos = xp;
    ypos = yp-sheight/2;
    spos = xpos + swidth/2 - sheight/2;
    newspos = spos;
    sposMin = xpos;
    sposMax = xpos + swidth - sheight/10;
    loose = l;
  }

  public void update() {
    if(over()) {
      over = true;
    } else {
      over = false;
    }
    if(mousePressed && over) {
      locked = true;
    }
    if(!mousePressed) {
      locked = false;
    }
    if(locked) {
      newspos = constrain(mouseX-sheight/16, sposMin, sposMax);
    }
    if(abs(newspos - spos) > 1) {
      spos = spos + (newspos-spos)/loose;
    }
  }

  public int constrain(int val, int minv, int maxv) {
    return min(max(val, minv), maxv);
  }

  public boolean over() {
    if(mouseX > xpos && mouseX < xpos+swidth &&
    mouseY > ypos && mouseY < ypos+sheight) {
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    noStroke();
    fill(120,0);
    rect(xpos, ypos, swidth, sheight);
    if(over || locked) {
      fill(0, 189, 242,80);
      cursor(HAND);
    } else {
      fill(255,80);
      cursor(ARROW);
    }
    rect(spos, ypos, sheight/10, sheight);
  }

  public float getPos() {
    // Convert spos to be values between
    // 0 and the total width of the scrollbar
    return spos * ratio;
  }
}

class PreferenceV1{




  PreferenceV1(){

  }




  public void display(){

    // Graphic


    pushMatrix();
    translate(804,86);
    noStroke();
    fill(0);
    rect(0,0,220,420);
    strokeWeight(1.5f);
    stroke(255);
    line(17,68,182,68);
    line(17,304,182,304);    

    //Dropdown triangel
    pushMatrix();
    translate(178,19);
    noStroke();
    fill(225,255,77);
    triangle(0, 10.5f, 12.125f, 10.5f, 12.125f/2, 0);
    popMatrix();  


    popMatrix(); 


    // Text 
    pushMatrix();
    translate(804,86);
    noStroke();
    fill(255);
    textFont(font1);
    int ind1 = 42;
    textAlign(LEFT);
    fill(225,255,77);
    text("DISPLAY PREFERENCE",16,30);
    fill(255);
    text("PARAMETERS",16,62);
    text("Bonding",ind1,92);
    text("Bulk",ind1,116);
    text("Burst index",ind1,140);
    text("Fiber length",ind1,164);
    text("Freeness",ind1,188);
    text("SEC",ind1,212);
    text("Tear index",ind1,236);
    text("Tensite index",ind1,260);

    text("VIEW OPTIONS",16,298);
    text("Value",ind1,326);
    text("Limits",ind1,350);
    text("Margins",ind1,374);
    text("Energy Efficiency",ind1,398);

    popMatrix();
  }












}



class PreferenceV2{



PImage icon1;
PImage icon2;



  PreferenceV2(){
    icon1 = loadImage("icon1.png");
    icon2 = loadImage("icon2.png");
  }
  






  public void display(){

    // Graphic
    pushMatrix();
    translate(804,86);
    noStroke();
    fill(0);
    rect(0,0,220,420);
    strokeWeight(1.5f);
    stroke(255);
    line(17,68,182,68);
    line(17,304,182,304);    

    //Dropdown triangel
    pushMatrix();
    translate(178,19);
    noStroke();
    fill(225,255,77);
    triangle(0, 10.5f, 12.125f, 10.5f, 12.125f/2, 0);
    popMatrix();  
    
    image(icon1,17,49);
    image(icon2,46,50);


    popMatrix(); 

    // Text 
    pushMatrix();
    translate(804,86);
    noStroke();
    fill(255);
    textFont(font1);
    int ind1 = 42;
    int ind2 = 76;
    textAlign(LEFT);
    fill(225,255,77);
    text("DISPLAY PREFERENCE",16,30);
    fill(255);
    text("PARAMETERS",ind2,62);
    fill(236,0,140);
    text("Bonding",ind2,92);
    fill(255);
    text("Bulk",ind2,116);
    text("Burst index",ind2,140);
    fill(193,255,28);
    text("Fiber length",ind2,164);
    fill(255);
    text("Freeness",ind2,188);
    text("SEC",ind2,212);
    fill(30,172,75);
    text("Tear index",ind2,236);
    fill(255);
    text("Tensite index",ind2,260);

    text("VIEW OPTIONS",16,298);
    text("Value",ind1,326);
    text("Limits",ind1,350);
    text("Target Value",ind1,374);
    text("Energy Efficiency",ind1,398);
    popMatrix();
  }












}



class Visualiser5axis
{
  XMLElement xml;

  int cols = 9;
  int rows = 180;
  int step = 14;
  float [][] A = new float[rows][cols];
  float [][] B = new float[rows*step][cols];
  float [][] K = new float[rows][cols];


  int i=0;
  int wait=1;
  int baseColour = 28;
  float alarm = 0;


  Visualiser5axis(XMLElement exml) {
    xml = exml;
  } 







  public void readData()
  {
    // Assign raw data to matrix A[][]
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        XMLElement onePoint = xml.getChild(i);
        A[i][j] = PApplet.parseFloat(onePoint.getChild(j).getContent());
      }
    }

    // calculate gap in each step and assign to matrix K[][]
    for (int i = 1; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        K[i-1][j] = (A[i][j] - A[i-1][j])/step;
      }
    }

    // Calculate plotting value ,row of matrix multiply by step
    /* example
     B[][] = [    A0           B0           C0           D0    ]
     A0 += KA0    B0 += KB0    C0 += KC0    D0 += KD0
     */
    // Assign Value for first row in plotting matrix B[][]
    for (int n = 0; n < cols; n++) {
      B[0][n] = A[0][n]; 
    }

    // Assign Value for the rest rows in plotting matrix B[][]
    int k=1; 
    int i=0;
    for (int m = 1; m < rows*step; m++) {    

      for (int n = 0; n < cols; n++){
        B[m][n] = B[m-1][n] + K[i][n];
      }

      // change K[][] value when complete steps
      k++;
      if (k == step+1){
        k=1;
        i++;
      }
    }
  }







  public void display(){
    //start drawing
    smooth();
    background(baseColour);
    float w=width/2-100, h=height/2;
    int l=250;
    float deg=2*PI/5;
    float deg2=3*PI/10;
    float op = 5;
    int repeat = rows*step;
    int history = 85;
    float eff = interpolate(B[i][8],1.65f,1.83f);
    //println(eff + "  "+B[i][8]);

    //declare war
    pushMatrix();
    translate(w,h);


    wait--;
    if (wait == 0){
      wait = 1;

      if (i < repeat-history){
        i++;
      }

      if (i == repeat-history){
        i=0;
      }
    }


    //set environment

    drawGradientDisc(0, 0,310,310, color(eff/1.5f,100,200-eff/1.8f,150),color(baseColour,255));

    

    stroke(255, 200);
    strokeWeight(1);

    if (alarm > 200){
      fill(random(255),0,0,random(140,255));
    }
    else{
      fill(baseColour);
    }

    ellipseMode(CENTER);
    ellipse(0,0,500,500);




    //noFill();
    stroke(255, 50);
    strokeWeight(.1f);
    fill(baseColour);
    ellipse(0,0,400,400);
    drawGradientDisc(0, 0,150,150, color(50,150),color(baseColour,255));

    noFill();
    stroke(255, 50); 
    strokeWeight(.1f); 
    line(0,-250,0,0);
    line(0, 0,l*sin(deg), -l*cos(deg));
    line(0, 0,-l*sin(deg), -l*cos(deg));
    line(0, 0,l*cos(deg2), l*sin(deg2));
    line(0, 0,-l*cos(deg2), l*sin(deg2));
    //set environment ending   





    for (int j=i ; j < i+history; j++){


      //get data from array, interpolate abd absolut with return funtion down there
      float Pa = interpolate(B[j][0], 1.60f, 1.75f);
      float Pb = interpolate(B[j][1], 25.46f, 27.20f);
      float Pc = interpolate(B[j][2], 15.03f, 16.30f);
      float Pd = interpolate(B[j][3], 7.40f, 8.70f);
      float Pe = interpolate(B[j][4], 556, 585);
      //float Pf = interpolate(A[j][5], 4.53, 5.5);
      //float Pg = interpolate(A[j][6], 70.88, 72.5);
      //float Ph = interpolate(A[j][7], 14.33, 16.10);

      alarm = Pe;
      //println(alarm);
      //start plotting

      //println(int(Pa) + "   "  +int(Pb) + "   "  +int(Pc) + "   "  +int(Pd) + "   "  +int(Pe)  +"   "+A[j][8]);



      //plot history lines


      if (j != i+history-1){

        strokeWeight(0.45f);
        stroke(180, op);
        beginShape();
        vertex(0 , -Pa);
        vertex(Pb*sin(deg), -Pb*cos(deg));
        vertex(Pc*cos(deg2), Pc*sin(deg2));
        vertex(-Pd*cos(deg2), Pd*sin(deg2));
        vertex(-Pe*sin(deg), -Pe*cos(deg));
        endShape(CLOSE);
      }

      //plot the last brightest line
      else{
        // colour the shape when the values go out of limit

        float alp = 0;

        if ( Pa > 150 || Pb > 150 || Pc > 150 || Pd > 150 || Pe > 150){
          float[] offMargin = {
            Pa, Pb, Pc, Pd, Pe                            };
          alp = max(offMargin);
          fill(255,242,0,alp%140*4);  
          stroke(255,242,0);
          beginShape();
          vertex(0 , -Pa);
          vertex(Pb*sin(deg), -Pb*cos(deg));
          vertex(Pc*cos(deg2), Pc*sin(deg2));
          vertex(-Pd*cos(deg2), Pd*sin(deg2));
          vertex(-Pe*sin(deg), -Pe*cos(deg));
          endShape(CLOSE);
          for (int g = 1; g < 255; g++)
          {
            stroke(255,242,0,alp%140*7/g);  
            //stroke(255,255,0, 255/g);
            noFill();
            strokeWeight(1.3f);
            //ellipse(height/2, width/2, r+glow, r+glow);
            beginShape();
            vertex(0 , -Pa-g);
            vertex((Pb+g)*sin(deg), (-Pb-g)*cos(deg));
            vertex((Pc+g)*cos(deg2), (Pc+g)*sin(deg2));
            vertex((-Pd-g)*cos(deg2), (Pd+g)*sin(deg2));
            vertex((-Pe-g)*sin(deg), (-Pe-g)*cos(deg));
            endShape(CLOSE);
            fill(255);
          }

          //stroke(255, 255);
          //strokeWeight(0.8);
        }

        else{ 
          stroke(255, 255);
          strokeWeight(1.35f);


          beginShape();
          vertex(0 , -Pa);
          vertex(Pb*sin(deg), -Pb*cos(deg));
          vertex(Pc*cos(deg2), Pc*sin(deg2));
          vertex(-Pd*cos(deg2), Pd*sin(deg2));
          vertex(-Pe*sin(deg), -Pe*cos(deg));
          endShape(CLOSE);
          fill(255);
        }
      }

      op += 0.8f;
      //end of each line
    }
    //END OF EACH SET!

    //reset line opaque
    op = 0;
    popMatrix();

    //End of the plot
  }



  //interpolate data
  public float interpolate(float Px, float target, float maximum){
    float k = 250/(maximum-target);
    Px = abs((Px-target)*k);
    return Px;
  }







  //gradient

  public void drawGradientDisc(float x,float y, float radiusX, float radiusY, int innerCol, int outerCol) {
    noStroke();
    beginShape(TRIANGLE_STRIP);
    for(float theta=0; theta<TWO_PI; theta+=TWO_PI/36) {
      fill(innerCol);
      vertex(x,y);
      fill(outerCol);
      vertex(x+radiusX*cos(theta),y+radiusY*sin(theta));
    }
    endShape();
  } 















}







class VisualiserInteractive
{
  XMLElement xml;



  int cols = 9;
  int rows = 180;
  int step = 14;

  VisualiserInteractive(XMLElement exml, int numSites) {
    xml = exml;
    println(numSites);
    rows = numSites;
    println(rows);
  } 



  float [][] A = new float[rows][cols];
  float [][] B = new float[rows*step][cols];
  float [][] K = new float[rows][cols];


  int i=0;
  int wait=1;
  int f;
  float ABvalue;
  int baseColour = 28;


  public void update(float any) {
    ABvalue = abs(any*(rows*step)/1450);
    f = PApplet.parseInt(ABvalue);
  }



  public void readData()
  {
    // Assign raw data to matrix A[][]
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        XMLElement onePoint = xml.getChild(i);
        A[i][j] = PApplet.parseFloat(onePoint.getChild(j).getContent());
      }
    }

    // calculate gap in each step and assign to matrix K[][]
    for (int i = 1; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        K[i-1][j] = (A[i][j] - A[i-1][j])/step;
      }
    }

    // Calculate plotting value ,row of matrix multiply by step
    /* example
     B[][] = [    A0           B0           C0           D0    ]
               A0 += KA0    B0 += KB0    C0 += KC0    D0 += KD0
     */
    // Assign Value for first row in plotting matrix B[][]
    for (int n = 0; n < cols; n++) {
      B[0][n] = A[0][n]; 
    }

    // Assign Value for the rest rows in plotting matrix B[][]
    int k=1; 
    int i=0;
    for (int m = 1; m < rows*step; m++) {    

      for (int n = 0; n < cols; n++){
        B[m][n] = B[m-1][n] + K[i][n];
      }

      // change K[][] value when complete steps
      k++;
      if (k == step+1){
        k=1;
        i++;
      }
    }
  }







  public void display(){
    //start drawing
    background(baseColour);
    float w=width/2-100, h=height/2;
    int l=100;
    float deg=2*PI/5;
    float deg2=3*PI/10;
    float op = 5;
    int repeat = rows*step;
    int history = 85;
    float eff = interpolate(B[f][8],1.65f,1.83f);
    //println(eff + "  "+B[i][8]);

    //declare war
    pushMatrix();
    translate(408,632);


    wait--;
    if (wait == 0){
      wait = 1;

      if (i < repeat-history){
        i++;
      }

      if (i == repeat-history){
        i=0;
      }
    }


    //set environment
    // Gradient the energy efficiency
    //drawGradientDisc(0, 0,120,120, color(eff/1.5,120,200-eff/1.8,255),color(baseColour,150));

    stroke(255, 160);
    strokeWeight(0.5f);
    fill(baseColour);
    ellipseMode(CENTER);
    ellipse(0,0,200,200);

    noFill();
    stroke(255, 100);
    ellipse(0,0,160,160);
    // Gradient the center for aesthetics
    drawGradientDisc(0, 0,100,100, color(70,150),color(baseColour,80));

    noFill();
    stroke(255, 100);  
    line(0,-100,0,0);
    
    stroke(30,172,75);//green
    line(0, 0,l*sin(deg), -l*cos(deg));
    
    stroke(193,255,28);//lima
    line(0, 0,-l*sin(deg), -l*cos(deg));
    
    stroke(255, 100);
    line(0, 0,l*cos(deg2), l*sin(deg2));
    
    stroke(236,0,140);//margenta
    line(0, 0,-l*cos(deg2), l*sin(deg2));
    //set environment ending   





    // for (int j=i ; j < i+history; j++){


    //get data from array, interpolate abd absolut with return funtion down there
    float Pa = interpolate(B[f][0], 1.60f, 1.75f);
    float Pb = interpolate(B[f][1], 25.46f, 27.20f);
    float Pc = interpolate(B[f][2], 15.03f, 16.30f);
    float Pd = interpolate(B[f][3], 7.40f, 8.70f);
    float Pe = interpolate(B[f][4], 556, 585);
    //float Pf = interpolate(A[j][5], 4.53, 5.5);
    //float Pg = interpolate(A[j][6], 70.88, 72.5);
    //float Ph = interpolate(A[j][7], 14.33, 16.10);


    //start plotting

    //println(int(Pa) + "   "  +int(Pb) + "   "  +int(Pc) + "   "  +int(Pd) + "   "  +int(Pe)  +"   "+A[j][8]);



    //plot history lines


    // if (j != i+history-1){
    noFill();
    strokeWeight(0.45f);
    stroke(180, op);
    beginShape();
    vertex(0 , -Pa);
    vertex(Pb*sin(deg), -Pb*cos(deg));
    vertex(Pc*cos(deg2), Pc*sin(deg2));
    vertex(-Pd*cos(deg2), Pd*sin(deg2));
    vertex(-Pe*sin(deg), -Pe*cos(deg));
    endShape(CLOSE);
    //   }

    //plot the last brightest line
    //  else{
    // colour the shape when the values go out of limit

        float alp = 0;

        if ( Pa > 60 || Pb > 60 || Pc > 60 || Pd > 60 || Pe > 60){
          float[] offMargin = {
            Pa, Pb, Pc, Pd, Pe                            };
          alp = max(offMargin);
          //fill(255,242,0,alp%140*4);  
          noFill();
          stroke(255,242,0);
          beginShape();
          vertex(0 , -Pa);
          vertex(Pb*sin(deg), -Pb*cos(deg));
          vertex(Pc*cos(deg2), Pc*sin(deg2));
          vertex(-Pd*cos(deg2), Pd*sin(deg2));
          vertex(-Pe*sin(deg), -Pe*cos(deg));
          endShape(CLOSE);
          for (int g = 1; g < 86; g++)
          {
            stroke(255,242,0,255/(3*g));  
            //stroke(255,255,0, 255/g);
            noFill();
            strokeWeight(1);
            //ellipse(height/2, width/2, r+glow, r+glow);
            noFill();
            beginShape();
            vertex(0 , -Pa-g);
            vertex((Pb+g)*sin(deg), (-Pb-g)*cos(deg));
            vertex((Pc+g)*cos(deg2), (Pc+g)*sin(deg2));
            vertex((-Pd-g)*cos(deg2), (Pd+g)*sin(deg2));
            vertex((-Pe-g)*sin(deg), (-Pe-g)*cos(deg));
            endShape(CLOSE);
            fill(255);
          }

          //stroke(255, 255);
          //strokeWeight(0.8);
        }

    else{ 
      stroke(255, 255);
      strokeWeight(1.35f);
    }
    noFill();
    beginShape();
    vertex(0 , -Pa);
    vertex(Pb*sin(deg), -Pb*cos(deg));
    vertex(Pc*cos(deg2), Pc*sin(deg2));
    vertex(-Pd*cos(deg2), Pd*sin(deg2));
    vertex(-Pe*sin(deg), -Pe*cos(deg));
    endShape(CLOSE);
    fill(255);
    //  }

    op += 0.8f;
    //end of each line
    //}
    //END OF EACH SET!

    //reset line opaque
    op = 0;
    popMatrix();

    //End of the plot
  }



  //interpolate data
  public float interpolate(float Px, float target, float maximum){
    float k = 100/(maximum-target);
    Px = abs((Px-target)*k);
    return Px;
  }







  //gradient

  public void drawGradientDisc(float x,float y, float radiusX, float radiusY, int innerCol, int outerCol) {
    noStroke();
    beginShape(TRIANGLE_STRIP);
    for(float theta=0; theta<TWO_PI; theta+=TWO_PI/36) {
      fill(innerCol);
      vertex(x,y);
      fill(outerCol);
      vertex(x+radiusX*cos(theta),y+radiusY*sin(theta));
    }
    endShape();
  } 















}




  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#666666", "--stop-color=#cccccc", "Papermill_Semifinal2" });
  }
}
